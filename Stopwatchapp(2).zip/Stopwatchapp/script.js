let [ms, s, m, h] = [0, 0, 0, 0];
let display = document.getElementById("display");
let timer = null;
let laps = document.getElementById("laps");

function updateDisplay() {
  let hrs = h < 10 ? "0" + h : h;
  let mins = m < 10 ? "0" + m : m;
  let secs = s < 10 ? "0" + s : s;
  let milli = ms < 10 ? "00" + ms : ms < 100 ? "0" + ms : ms;
  display.innerText = `${hrs}:${mins}:${secs}:${milli}`;
}

function startTimer() {
  if (timer !== null) return;
  timer = setInterval(() => {
    ms += 10;
    if (ms >= 1000) {
      ms = 0;
      s++;
      if (s == 60) {
        s = 0;
        m++;
        if (m == 60) {
          m = 0;
          h++;
        }
      }
    }
    updateDisplay();
  }, 10);
}

function pauseTimer() {
  clearInterval(timer);
  timer = null;
}

function resetTimer() {
  clearInterval(timer);
  [ms, s, m, h] = [0, 0, 0, 0];
  updateDisplay();
  timer = null;
  laps.innerHTML = "";
}

function recordLap() {
  const lapTime = display.innerText;
  const li = document.createElement("li");
  li.textContent = `Lap: ${lapTime}`;
  laps.appendChild(li);
}

document.getElementById("start").addEventListener("click", startTimer);
document.getElementById("pause").addEventListener("click", pauseTimer);
document.getElementById("reset").addEventListener("click", resetTimer);
document.getElementById("lap").addEventListener("click", recordLap);

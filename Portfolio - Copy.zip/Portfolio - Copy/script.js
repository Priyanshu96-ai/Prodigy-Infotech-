// You can add interactivity later like typing animation, form validation, etc.
console.log("Portfolio Loaded Successfully!");
